#ifndef SKYBOX_H
#define SKYBOX_H

#include <string.h>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>

#include "Readtex.h"

#include <GL/glut.h>
#include "../glm/glm.h"

extern GLfloat Xrot, Yrot;
extern GLfloat EyeDist;

/**
 * class Skybox
 */
class Skybox
{
 public:
  
  // Constructors/Destructors
  //  
  
  /**
   * Empty Constructor
   */
  Skybox ( );
  
  /**
   * Empty Destructor
   */
  virtual ~Skybox ( );
  
  // Static Public attributes
  //  
  
  // Public attributes
  //  
  
  // Public attribute accessor methods
  //  
  
  /**
   * @param  x
   * @param  y
   * @param  s
   */
  
  /**
   * 
   * 
   */
  
 protected:
  
  // Static Protected attributes
  //  
  
  // Protected attributes
  //  
  
 public:
  
  // Protected attribute accessor methods
  //  
  
 protected:
  
 public:
  
  // Public attribute accessor methods
  //  
  void draw_skybox(void);
  void load_envmaps(void);
  void set_mode(GLuint mode);
  void load(GLenum target, const char *filename, GLboolean flipTB, GLboolean flipLR);
  
 protected:
  
 private:
  
  // Static Private attributes
  //  
  
  // Private attributes
  //  
  
 public:
  
  // Private attribute accessor methods
  //  
  
 private:
  
 public:
  
  // Private attribute accessor methods
  //  
  
 private:
  
};

#endif // SKYBOX_H
