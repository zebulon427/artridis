#ifndef TERRAIN_H
#define TERRAIN_H

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Scene.h"
#include "Readtex.h"

#ifdef WIN32
#include <windows.h>
#endif

#include <GL/glut.h>

#ifdef XMESA
#include "GL/xmesa.h"
static int fullscreen = 1;
#endif

#ifndef M_PI
#define M_PI 3.14159265
#endif

#define BUFSIZE 512
#define   MAX_NO_TEXTURES 2

extern GLuint texture_id[];
extern GLboolean isFogged;

extern GLint heightMnt;
extern GLint lenghtXmnt;
extern GLint lenghtYmnt;

extern GLfloat stepXmnt;
extern GLfloat stepYmnt;

/**
 * class Terrain
 */
class Terrain
{
 public:
  
  // Constructors/Destructors
  //  
  
  
  /**
   * Empty Constructor
   */
  Terrain ( );
  
  /**
   * Empty Destructor
   */
  virtual ~Terrain ( );
  
  // Static Public attributes
  //  
  
  // Public attributes
  //  
  
  // Public attribute accessor methods
  //  
  
  /**
   * @param  x
   * @param  y
   * @param  s
   */
  
  /**
   * 
   * 
   */
  
 protected:
  
  // Static Protected attributes
  //  
  
  // Protected attributes
  //  
  
 public:
  
  // Protected attribute accessor methods
  //  

protected:

public:

  // Public attribute accessor methods
  //  
  void drawTerrain(void);
  void load_envmaps(void);
  void set_mode(GLuint mode);
  void load(GLenum target, const char *filename, GLboolean flipTB, GLboolean flipLR);
  
protected:
  
  
private:
  
  // Static Private attributes
  //  
  
  // Private attributes
  //  

public:

  // Private attribute accessor methods
  //  

private:
  
public:

  // Private attribute accessor methods
  //  

private:

};

#endif // TERRAIN_H
