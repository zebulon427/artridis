// Object.h François Gez 08 Juillet 2008
//See page 17, Object oriented programming from John Turner

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <GL/glut.h>
#include "../glm/glm.h"
#include "dirent32.h"

#include "Scene.h"

extern GLfloat    smoothing_angle;	/* smoothing angle */
extern GLuint     material_mode;	/* 0=none, 1=color, 2=material */
extern GLboolean  facet_normal;	        /* draw with facet normal? */

class Object
{
 public:
  
  Object(); //Default constructor
  Object (int index, char *name, GLfloat xpos, GLfloat ypos, GLfloat zpos, GLfloat scale);
  ~Object(); //Default destructor
  
  void setName(char *); //mutator function  
  void setIndex(int); //mutator function  
  void setXpos(GLfloat); //mutator function  
  void setYpos(GLfloat); //mutator function  
  void setZpos(GLfloat); //mutator function
  void setScale(GLfloat); //mutator function
  
  char * getName(); //accessor function
  int getIndex(); //accessor function
  GLfloat getXpos(); //accessor function
  GLfloat getYpos(); //accessor function
  GLfloat getZpos(); //accessor function
  GLfloat getScale(); //accessor function
  
 private:
  
  char *name;
  int index;
  GLfloat xpos, ypos, zpos, scale;
};
