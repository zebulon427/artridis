/** @file Main.cpp
    @brief This program is containing the main function
    * 
    * Much of this code was borrowed from SGI's tk OpenGL toolkit.
    * This mouse selection's code was created by Jeff Molofee '99
    *  If you've found this code useful, please let me know.
    * Visit me at www.demonews.com/hosted/nehe
    **************************************************************
    * This code was ported to MacOS by Tony Parker.
    *  I'd also appreciate it if you could drop me a line if you found
    *  this code useful. 
    *  Tony Parker - asp@usc.edu
    * Have a nice day.
    * Mac OS X Conversion by Chad Armstrong (chad@edenwaith.com)
    * 1. Add these three Frameworks to the External Frameworks folder
    *    Foundation
    *    GLUT
    *    OpenGL
    * 2. Change the header <glut.h> to <GLUT/glut.h>
    * 3. Comment out the <gl.h> and <glu.h> headers
    
    @author Francois Gez
    @date 19/10/2008
*/


#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <GL/glut.h>
#include "dirent32.h"
#include "../glm/glm.h"

#include "Scene.h"
#include "Object.h"
#include "Skybox.h"
#include "Terrain.h"

#if defined(_WIN32)
#include <sys/timeb.h>
#include <gl/win.h>

#else
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h>
#endif

#ifndef CLK_TCK
#define CLK_TCK 1000
#endif

#define MAX_GRID_SIZE 40
#define SIZE (MAX_GRID_SIZE * MAX_GRID_SIZE * MAX_GRID_SIZE)
#define NUM_FRAMES 5

int winWidth = 800;
int winHeight = 600;
Scene ascene1, ascene2;
Skybox askybox2;
Terrain aterrain;
Object main_object1;


// Function Prototypes -------------------------------------------------------

/** Display the world.    
    @return void there is nothing to return here.
    @param void parameter.
*/
void display(void) /* spheres of various colors for light */
{
  GLfloat position[] = {0.0, 20.0, 0.0, 1.0};
  GLfloat red_ambient[]  = { 0.4, 0.0, 0.0, 0.0 }; /* red ambient */
  GLfloat red_diffuse[] =  { 0.6, 0.0, 0.0, 1.0 }; /* red diffuse */
  GLfloat blue_ambient[]  = { 0.0, 0.0, 0.4, 1.0 }; /* blue ambient */
  GLfloat blue_diffuse[] =  { 0.0, 0.0, 0.6, 1.0 }; /* blue diffuse */
  GLfloat moon_ambient[]  = { 0.4, 0.4, 0.4, 1.0 }; /* white ambient */
  GLfloat moon_diffuse[] =  { 0.6, 0.6, 0.6, 1.0 }; /* white diffuse */
  GLfloat sun_ambient[]  = { 1.0, 1.0, 0.0, 0.0 }; /* sun ambient */
  GLfloat sun_diffuse[] =  { 1.0, 1.0, 0.0, 0.0 }; /* sun diffuse */
  int height = glutGet(GLUT_WINDOW_HEIGHT);  
  
  static char s[256], t[32], *h;
  static char* p;
  static int frames = 0;
  int lock = 0;
  
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  
  /* projection transformation */
  
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  gluPerspective(fovy, (GLfloat)winWidth / (GLfloat)winHeight, near, far);
  
  ascene1.calcposobs();
  
  glPushMatrix();	    
  
  glInitNames();
  glPushName(0);
  
  /* modelview transformation */				  
  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity();
  
  
  gluLookAt(obs[0], obs[1], obs[2],obs[0] + dir[0], obs[1] + dir[1], obs[2] + dir[2],0.0, 0.0, 1.0);
  
  glMaterialfv(GL_FRONT, GL_AMBIENT, moon_ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, moon_diffuse);
  glMaterialfv(GL_BACK, GL_AMBIENT, moon_ambient);
  glMaterialfv(GL_BACK, GL_DIFFUSE, moon_diffuse);
  
  glPushMatrix();
  
  /* terrain */
  glRotatef(90.0, 1.0, 0.0, 0.0);
  glTranslatef( 0.0, -30.0, 0.0 );
  
  aterrain.drawTerrain();
  
  glPopMatrix();	    
  
  if(objectFlag == 1)
    { 
      loadObject(GL_RENDER);	
      objectFlag = 0;
    }	   
  
  if (move)
    {
      ascene1.moveObject();    
    }
  
  glPushMatrix(); 
  
  initLoaded(GL_RENDER);
  
  /* skybox */
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);
  glDisable(GL_TEXTURE_GEN_R);
  glPopMatrix();	    
  
  glPushMatrix();	    
  glTranslatef( 0.0, 0.0, obs[2] );
  glTranslatef( 0.0, obs[1], 0.0 );
  glTranslatef( obs[0], 0.0, 0.0 );
  
  glRotatef(Xrot, 1, 0, 0);
  glRotatef(Yrot, 0, 1, 0);
  
  askybox2.draw_skybox();
  
  glPopMatrix();	    
  
  glMatrixMode(GL_TEXTURE);
  glLoadIdentity();
  glRotatef(-Yrot, 0, 1, 0);
  glRotatef(-Xrot, 1, 0, 0);
  
  glPushMatrix();
  
  glDisable(GL_LIGHTING);
  
  if(fogged)
    glEnable(GL_FOG);
  else
    glDisable(GL_FOG);
  
  
  if(rotate > 0)
    {
      ascene2.rotateObject();
    }  
  
  if(scaleflag > 0)
    {
      ascene2.scaleObject();
    } 
  
  if(del > 0)
    {
      ascene2.deleteObject();
    }  
  
  if (!help) {
    /* XXX - this could be done a _whole lot_ faster... */
    h = "help\n\nLeft Click         -  Select object to manipulate\nRight click        -  Unselect object\nw         -  Toggle wireframe/filled\nm         -  Toggle color/material/none mode\np         -  Toggle performance indicator\nt         -  Show model stats\na         -  Move camera(object when left clicked) forward\nd         -  Move camera(object when left clicked) backward\ns         -  Stop camera\nx/X        -  Rotate object(when left clicked) on X axis\ny/Y        -  Rotate object(when left clicked) on Y axis\nz/Z        -  Rotate object(when left clicked) on Z axis\nDel       -  Remove the object (when left clicked)\nTAB       -  Reset camera and object position\nR/A       -  Camera looks on the right\nL/A       -  Camera looks on the left\nU/A       -  Camera looks up\nD/A       -  Camera looks down\nj       -  Previous Object\nk       -  Load Object\nl       -  Next Object\n<       -  Hide sub window\n>       -  Show sub window\nescape  -  Quit\n";
    
    ascene1.shadowtext(winWidth-winWidth*0.7, winHeight-winHeight*0.1, h);
  }
  
  if (stats) {
    /* XXX - this could be done a _whole lot_ faster... */
    
    sprintf(s, "%s\n%d vertices\n%d triangles\n%d normals\n"
	    "%d texcoords\n%d groups\n%d materials",
	    model->pathname, model->numvertices, model->numtriangles, 
	    model->numnormals, model->numtexcoords, model->numgroups,
	    model->nummaterials);
    ascene1.shadowtext(winWidth-winWidth*0.95, winHeight-winHeight*0.2, s);
  }
  
  /* spit out frame rate. */
  frames++;
  if (frames > NUM_FRAMES) {
    sprintf(t, "%g fps", frames/ascene1.elapsed());
    frames = 0;
  }
  
  if (performance) {
    ascene1.shadowtext(winWidth-winWidth*0.2, winHeight-winHeight*0.9, t);
  }
  
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);
  glEnable(GL_TEXTURE_GEN_R);    
  glPopMatrix();
  glPopMatrix();
  
  glutSwapBuffers();
  glutPostRedisplay();
  
  glFlush();
}

/** Another display function, this one will be 
    used to update the graphic subwindow    
    @return void there is nothing to return here.
    @param void parameter.
*/
void 
subdisplay ()
{
  GLfloat moon_ambient[]  = { 0.4, 0.4, 0.4, 1.0 }; /* white ambient */
  GLfloat moon_diffuse[] =  { 0.6, 0.6, 0.6, 1.0 }; /* white diffuse */
  GLfloat subfovy = 15.0, subfar = 20.0;
  /* Clear subwindow */  
  glutReshapeWindow (winWidth/8, winHeight/8);
  glutPositionWindow (0, winHeight-195);
  glutSetWindow (subwindow);
    glClearColor (0.45, 0.25, 0.95, 0.0);
  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glDisable(GL_LIGHTING);
  
  glEnable(GL_TEXTURE_GEN_S);
  glEnable(GL_TEXTURE_GEN_T);
  glEnable(GL_TEXTURE_GEN_R); 
  
  glMatrixMode( GL_PROJECTION );
  glLoadIdentity();
  
  gluPerspective( subfovy, aspect,  near, subfar ); /* perspective projection */
  
  glPushMatrix();	    
  
  glInitNames();
  glPushName(0);
  
  /* modelview transformation */				  
  glMatrixMode( GL_MODELVIEW );
  glLoadIdentity();
  
  gluLookAt(0.0, -5.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, 1.0); 
  
  glMaterialfv(GL_FRONT, GL_AMBIENT, moon_ambient);
  glMaterialfv(GL_FRONT, GL_DIFFUSE, moon_diffuse);
  glMaterialfv(GL_BACK, GL_AMBIENT, moon_ambient);
  glMaterialfv(GL_BACK, GL_DIFFUSE, moon_diffuse);
  
  initCaroussel(GL_RENDER);
  
  glDisable(GL_TEXTURE_GEN_S);
  glDisable(GL_TEXTURE_GEN_T);
  glDisable(GL_TEXTURE_GEN_R); 
  glDisable(GL_LIGHTING);  
  glPopMatrix();       
  glPushMatrix();
  
  /* Draw border */
  glColor3f (0.0F, 1.0F, 0.0F);
  glBegin (GL_LINE_LOOP);
  glVertex2f (0.0F, 0.0F);
  glVertex2f (0.0F, 0.99F);
  glVertex2f (0.999F, 0.99F);
  glVertex2f (0.999F, 0.0F);
  glEnd ();
  
  glClearColor (1.0, 1.0, 1.0, 0.0);
  
  glPopMatrix();
  
  glutSwapBuffers ();
  glutPostRedisplay();
  glFlush();
}

/** Traditional main used as the entrance in the execution of the program
    @return int error flag parameter
    there is nothing to return here.
    @param int argc number of arguments
    @param char** pointer of poiner to char representing the command line arguments
*/
int main (int argc, char **argv)
{
  /* Glut initializations */
  glutInitWindowSize (winWidth, winHeight);
  glutInit (&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  
  /* Main window creation and setup */
window = glutCreateWindow (argv[0]);
  init(1);
  glutDisplayFunc (display);
  glutReshapeFunc (reshape);
  
  glutMouseFunc(mouse_function);
  glutKeyboardFunc (keyboard);
  glutSpecialFunc(special);
    
  //  Tells whether to display the window full screen or not
  //  Press Alt + Esc to exit a full screen.
  //  View in full screen if the fullscreen flag is on
  if (full_screen)
    glutFullScreen ();
  
  /* Sub window creation and setup */
subwindow = glutCreateSubWindow (window, 0.0, 0.0, 50, 50);    
  init(1);
      
  glutDisplayFunc (subdisplay);
  glutReshapeFunc (subreshape);
  
  glutKeyboardFunc (keyboard);
  glutSpecialFunc(special);
glutMainLoop ();
  
  return 0;
};


