/**@file Terrain.cpp
 * @brief This program is under the GNU GPL.
 * Use at your own risk.
 *
 * written by David Bucciarelli (tech.hmw@plus.it)
 *            Humanware s.r.l.
 *
 * based on a Mikael SkiZoWalker's (MoDEL) / France (Skizo@Hol.Fr) demo
 */

#include "Terrain.h"

static GLint T0 = 0;
static GLint Frames = 0;

#define TSCALE 4

static GLfloat terrain[256 * 256];
static int win = 0;
static float v1[2], v2[2];

GLuint texture_id[MAX_NO_TEXTURES];
GLint sphereMap[] = {GL_SPHERE_MAP};
float *minFilter, *magFilter, *sWrapMode, *tWrapMode;

float modulate[] = {GL_MODULATE};
float repeat[] = {GL_REPEAT};
float clamp[] = {GL_CLAMP};
float nnearest[] = {GL_NEAREST};
float linear[] = {GL_LINEAR};
float nearest_mipmap_nearest[] = {GL_NEAREST_MIPMAP_NEAREST};
float nearest_mipmap_linear[] = {GL_NEAREST_MIPMAP_LINEAR};
float linear_mipmap_nearest[] = {GL_LINEAR_MIPMAP_NEAREST};
float linear_mipmap_linear[] = {GL_LINEAR_MIPMAP_LINEAR};

float *textureEnvironment = modulate;

GLint heightMnt = 45;
GLint lenghtXmnt = 62;
GLint lenghtYmnt = 62;
GLfloat stepXmnt = 96.0;
GLfloat stepYmnt = 96.0;

static float ModZMnt;
static long GlobalMnt = 450;

// Constructors/Destructors
//  

/** Default Constructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Terrain::Terrain ( ) { }

/** Default Destructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Terrain::~Terrain ( ) { }

// Global Variables ----------------------------------------------------------

/** This function is used by the Init function to set some texture variables.
    @return void there is nothing to return
    @param void there is no parameters here.
*/
void SetDefaultSettings(void)
{
    magFilter = nnearest;
    minFilter = nnearest;
    sWrapMode = repeat;
    tWrapMode = repeat;
    textureEnvironment = modulate;
}

/** This function is used by the Init function to set some texture variables.
    @return void there is nothing to return
    @param void there is no parameters here.
*/
static int
clipstrip(float y, float *start, float *end)
{
   float x1, x2, t1, t2, tmp;

   if (v1[1] == 0.0) {
      t1 = 0.0;
      x1 = -HUGE_VAL;
   }
   else {
      t1 = y / v1[1];
      x1 = t1 * v1[0];
   }

   if (v2[1] == 0.0) {
      t2 = 0.0;
      x2 = HUGE_VAL;
   }
   else {
      t2 = y / v2[1];
      x2 = t2 * v2[0];
   }

   if (((x1 < -(lenghtXmnt * stepXmnt) / 2) && (t2 <= 0.0)) ||
       ((t1 <= 0.0) && (x2 > (lenghtXmnt * stepXmnt) / 2)) ||
       ((t1 < 0.0) && (t2 < 0.0)))
      return 0;

   if ((t1 == 0.0) && (t2 == 0.0)) {
      if ((v1[0] < 0.0) && (v1[1] > 0.0) && (v2[0] < 0.0) && (v2[1] < 0.0)) {
	 *start = -(lenghtXmnt * stepXmnt) / 2;
	 *end = stepXmnt;
	 return 1;
      }
      else {
	 if ((v1[0] > 0.0) && (v1[1] < 0.0) && (v2[0] > 0.0) && (v2[1] > 0.0)) {
	    *start = -stepXmnt;
	    *end = (lenghtXmnt * stepXmnt) / 2;
	    return 1;
	 }
	 else
	    return 0;
      }
   }
   else {
      if (t2 < 0.0) {
	 if (x1 < 0.0)
	    x2 = -(lenghtXmnt * stepXmnt) / 2;
	 else
	    x2 = (lenghtXmnt * stepXmnt) / 2;
      }

      if (t1 < 0.0) {
	 if (x2 < 0.0)
	    x1 = -(lenghtXmnt * stepXmnt) / 2;
	 else
	    x1 = (lenghtXmnt * stepXmnt) / 2;
      }
   }

   if (x1 > x2) {
      tmp = x1;
      x1 = x2;
      x2 = tmp;
   }

   x1 -= stepXmnt;
   if (x1 < -(lenghtXmnt * stepXmnt) / 2)
      x1 = -(lenghtXmnt * stepXmnt) / 2;

   x2 += stepXmnt;
   if (x2 > (lenghtXmnt * stepXmnt) / 2)
      x2 = (lenghtXmnt * stepXmnt) / 2;

   *start = ((int) (x1 / stepXmnt)) * stepXmnt;
   *end = ((int) (x2 / stepXmnt)) * stepXmnt;

   return 1;
}

/** Initialisation function 
 *
 @return void there is nothing to return here.
 @param void there is no parameters here.
*/
void
initTerrain(void)
{
  int h, i, idx, ox, oy;
  float j, k, start, end;
  
  ox = (int) (obs[0] / stepXmnt);
  oy = (int) (obs[1] / stepYmnt);
  GlobalMnt = ((ox * TSCALE) & 255) + ((oy * TSCALE) & 255) * 256;
  
  glPushMatrix();
  glTranslatef((float) ox * stepXmnt, 0, (float) oy * stepYmnt);
  
  for (h = 0, k = -(lenghtYmnt * stepYmnt) / 2; h < lenghtYmnt;
       k += stepYmnt, h++) {
    if (!clipstrip(k, &start, &end))
      continue;
    
    glBegin(GL_TRIANGLE_STRIP);	/* I hope that the optimizer will be able to improve this code */
    for (i = (int) (lenghtXmnt / 2 + start / stepXmnt), j = start; j <= end;
	 j += stepXmnt, i++) {
      idx = (i * TSCALE + h * 256 * TSCALE + GlobalMnt) & 65535;
      glTexCoord2f((ox + i) / 8.0, (oy + h) / 8.0);
      glVertex3f(j, terrain[idx], k);
      
      idx = (i * TSCALE + h * 256 * TSCALE + 256 * TSCALE + GlobalMnt) & 65535;
      glTexCoord2f((ox + i) / 8.0, (oy + h + 1) / 8.0);
      glVertex3f(j, terrain[idx], k + stepYmnt);
    }
    glEnd();
  }
  
  glBegin(GL_QUADS);
  glVertex3f(-(lenghtXmnt * stepXmnt) / 2.0, heightMnt * 0.6,
	     -(lenghtYmnt * stepYmnt) / 2.0);
  glVertex3f(-(lenghtXmnt * stepXmnt) / 2.0, heightMnt * 0.6,
	     (lenghtYmnt * stepYmnt) / 2.0);
  glVertex3f((lenghtXmnt * stepXmnt) / 2.0, heightMnt * 0.6,
	     (lenghtYmnt * stepYmnt) / 2.0);
  glVertex3f((lenghtXmnt * stepXmnt) / 2.0, heightMnt * 0.6,
	     -(lenghtYmnt * stepYmnt) / 2.0);
  glEnd();
  
  glPopMatrix();
  
#ifdef XMESA
 case ' ':
   XMesaSetFXmode(fullscreen ? XMESA_FX_FULLSCREEN : XMESA_FX_WINDOW);
   fullscreen = (!fullscreen);
   break;
#endif
}


/** Display function 
 *
 @return void there is nothing to return here.
 @param void there is no parameters here.
*/
void
Terrain::drawTerrain(void)
{    
  float ambient[] = {0.6, 0.7, 0.6, 0.2};
  float diffuse[] = {1.0, 1.0, 1.0, 1.0};
  float specular[] = {1.0, 1.0, 1.0, 1.0};
  float position[] = {0.0, 60.0,  40.0, 0.0};
  float fog_color[] = {0.6, 0.7, 0.6, 1.0};
  float mat_ambient[] = {0.0, 0.0, 0.0, 0.2};
  float mat_shininess[] = {0.5};
  float mat_specular[] = {0.5, 0.5, 0.5, 0.2};
  float mat_diffuse[] = {0.8, 0.8, 0.8, 1.0};
  float lmodel_ambient[] = {0.2, 0.2, 0.2, 1.0};
  float lmodel_twoside[] = {GL_TRUE};
  
  SetDefaultSettings();
  
  glClearColor(fog_color[0], fog_color[1], fog_color[2], fog_color[3]);
  glClearDepth(1.0);
  glDepthFunc(GL_LEQUAL);
  glShadeModel(GL_SMOOTH);
  
  glDisable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glFogi(GL_FOG_MODE, GL_EXP2);
  
#ifdef FX
  glHint(GL_FOG_HINT, GL_NICEST);
#endif
  
  glFogf(GL_FOG_DENSITY, 0.003);
  glFogi(GL_FOG_MODE, GL_LINEAR);
  glFogf(GL_FOG_START, 300.0);
  glFogf(GL_FOG_END, 500.0);
  glFogfv(GL_FOG_COLOR, fog_color);
  
  glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
  glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
  glLightfv(GL_LIGHT0, GL_POSITION, position);
  glEnable(GL_LIGHT0);
    
  glMaterialfv(GL_BACK, GL_SHININESS, mat_shininess);
  glMaterialfv(GL_BACK, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_BACK, GL_DIFFUSE, mat_diffuse);
  glMaterialfv(GL_BACK, GL_AMBIENT, mat_ambient);
  
  glTexGeniv(GL_S, GL_TEXTURE_GEN_MODE, sphereMap);
  
  glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, magFilter);
  glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, minFilter);
  glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, sWrapMode);
  glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, tWrapMode);
  
  glTexEnvfv(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, textureEnvironment);
  glPixelStorei ( GL_UNPACK_ALIGNMENT, 1 );

  initTerrain();    
}
