/** @file Object.cpp 
    @brief This program is my Object oriented development for handling of the Mesh objects
    * Constructors and (later) destructors.
    * Thanks to John Turner from Westminster University, getter and setter "methods"
      @author Francois Gez
    *@date 19/10/2008
*/

#include "Object.h"

GLfloat smoothing_angle = 90.0;	        /* smoothing angle */
GLuint material_mode = 0;		/* 0=none, 1=color, 2=material */
GLboolean facet_normal = GL_FALSE;	/* draw with facet normal? */  
GLfloat scale = 10.0;			/* original scale factor */

// Constructors/Destructors
//  

/** Default Constructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Object::Object ( ) { 
  index = 1;
  name = "lighthouse.obj";
  xpos = 5.0;
  ypos = 0.0;
  zpos = 0.0;  
  scale = 10.0;
}

/** Default Constructor
    @return void there is nothing to return from a constructor.
    @param anidex int Index number of the object
    @param aname char* pathname of the obj file
    @param axpos GLfloat x position 
    @param axpos GLfloat y position 
    @param axpos GLfloat z position
    @param ascale GLfloat Scale of the object 
*/
Object::Object (int anindex, char *aname, GLfloat axpos, GLfloat aypos, GLfloat azpos, GLfloat ascale) { 
  index = anindex;
  name = aname;
  xpos = axpos;
  ypos = aypos;
  zpos = azpos;
  scale = ascale;
  
  if(mode == GL_SELECT)
    {  
      glLoadName(anindex);	  
    }
  
  /* read in the model */
  model = glmReadOBJ(name);
  scale = glmUnitize(model);
  if(ascale <= 0.0)
    ascale = 1.0;
  
  glmScale(model, ascale);
  
  glmVertexNormals(model, smoothing_angle, GL_TRUE);
  
  glTranslatef(xpos, 0.0, 0.0);
  glTranslatef(0.0, ypos, 0.0);
  glTranslatef(0.0, 0.0, zpos);
  
  if (material_mode == 0) {
    if (facet_normal)
      glmDraw(model, GLM_FLAT);
    else
      
      glmDraw(model, GLM_SMOOTH);
  } else if (material_mode == 1) {
    if (facet_normal)
      glmDraw(model, GLM_FLAT | GLM_COLOR);
    else
      glmDraw(model, GLM_SMOOTH | GLM_COLOR);
  } else if (material_mode == 2) {
    if (facet_normal)
      glmDraw(model, GLM_FLAT | GLM_MATERIAL | GLM_TEXTURE);
    else
      glmDraw(model, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
  }    
}

/** Default Destructor
    @return void there is nothing to return from a destructor.
    @param void parameter.
*/
Object::~Object ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  

/**
 * @return int
 */
int Object::getIndex (void) {
  return index;
}

/**
 * @return char *
 */
char * Object::getName (void) {
  return name;
}

/**
 * @return GLfloat
 */
GLfloat Object::getXpos (void) {
  return xpos;
}

/**
 * @return GLfloat
 */
GLfloat Object::getYpos (void ) {
  return ypos;
}

/**
 * @return GLfloat
 */
GLfloat Object::getZpos (void) {
  return zpos;
}

/**
 * @return GLfloat
 */
GLfloat Object::getScale (void) {
  return scale;
}

/**
 * @param  name
 */
void Object::setName (char * aname) {
  name = aname;
}

/**
 * @param  index
 */
void Object::setIndex (int anindex) {
  index = anindex;
}

/**
 * @param  xpos
 */
void Object::setXpos (GLfloat axpos) {
  xpos = axpos;
}

/**
 * @param  ypos
 */
void Object::setYpos (GLfloat aypos) {
  ypos = aypos;
}

/**
 * @param  zpos
 */
void Object::setZpos (GLfloat azpos) {
  zpos = azpos;
}

/**
 * @param  scale
 */
void Object::setScale (GLfloat ascale) {
  scale = ascale;
}

