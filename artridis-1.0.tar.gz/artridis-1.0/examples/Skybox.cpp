/** @file Skybox.cpp
   @brief This program is building the sbybox
 * 
   @author Francois Gez
   @date 03/11/2008
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>
#include <GL/glut.h>
#include "dirent32.h"

#include "Skybox.h"
#include "Readtex.h"

GLfloat Xrot = 0, Yrot = 0;
GLfloat EyeDist = 0.0;
static GLboolean use_vertex_arrays = GL_FALSE;
static GLboolean anim = GL_TRUE;

#define eps1 0.99
#define br   400.0  /* box radius */

static const GLfloat tex_coords[] = {
  /* +X side */
  1.0, -eps1, -eps1,
  1.0, -eps1,  eps1,
  1.0,  eps1,  eps1,
  1.0,  eps1, -eps1,
  
  /* -X side */
  -1.0,  eps1, -eps1,
  -1.0,  eps1,  eps1,
  -1.0, -eps1,  eps1,
  -1.0, -eps1, -eps1,
  
  /* +Y side */
  -eps1, 1.0, -eps1,
  -eps1, 1.0,  eps1,
  eps1, 1.0,  eps1,
  eps1, 1.0, -eps1,
  
  /* -Y side */
  -eps1, -1.0, -eps1,
  -eps1, -1.0,  eps1,
  eps1, -1.0,  eps1,
  eps1, -1.0, -eps1,
  
  /* +Z side */
  eps1, -eps1, 1.0,
  -eps1, -eps1, 1.0,
  -eps1,  eps1, 1.0,
  eps1,  eps1, 1.0,
  
  /* -Z side */
  eps1,  eps1, -1.0,
  -eps1,  eps1, -1.0,
  -eps1, -eps1, -1.0,
  eps1, -eps1, -1.0,
};

static const GLfloat vtx_coords[] = {
  /* +X side */
  br, -br, -br,
  br, -br,  br,
  br,  br,  br,
  br,  br, -br,
  
  /* -X side */
  -br,  br, -br,
  -br,  br,  br,
  -br, -br,  br,
  -br, -br, -br,
  
  /* +Y side */
  -br,  br, -br,
  -br,  br,  br,
  br,  br,  br,
  br,  br, -br,
  
  /* -Y side */
  -br, -br, -br,
  -br, -br,  br,
  br, -br,  br,
  br, -br, -br,
  
  /* +Z side */
  br, -br, br,
  -br, -br, br,
  -br,  br, br,
  br,  br, br,
  
  /* -Z side */
  br,  br, -br,
  -br,  br, -br,
  -br, -br, -br,
  br, -br, -br,
};

// Constructors/Destructors
//  

/** Default Constructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Skybox::Skybox ( ) { }

/** Default Destructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Skybox::~Skybox ( ) { }


// Global Variables ----------------------------------------------------------

GLfloat	rtri;			// Angle For The Triangle
GLfloat	rquad;			// Angle For The Quad

/** Draw the skybox.    
    @return void there is nothing to return here.
    @param void parameter.
*/
void Skybox::draw_skybox( void )
{
  if ( use_vertex_arrays ) {
    glTexCoordPointer( 3, GL_FLOAT, 0, tex_coords );
    glVertexPointer(   3, GL_FLOAT, 0, vtx_coords );
    
    glEnableClientState( GL_TEXTURE_COORD_ARRAY );
    glEnableClientState( GL_VERTEX_ARRAY );
    
    glDrawArrays( GL_QUADS, 0, 24 );
    
    glDisableClientState( GL_TEXTURE_COORD_ARRAY );
    glDisableClientState( GL_VERTEX_ARRAY );
  }
  else {
    unsigned   i;
    
    glBegin(GL_QUADS);
    
    for ( i = 0 ; i < 24 ; i++ ) {
      glTexCoord3fv( & tex_coords[ i * 3 ] );
      glVertex3fv  ( & vtx_coords[ i * 3 ] );
    }
    glEnd();
  }
}


/** Set the ARB mode.    
    @return void there is nothing to return here.
    @param mode GLuint whether it is a reflection or a normal ARB mode.
*/
void Skybox::set_mode(GLuint mode)
{
  if (mode == 0) {
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
    glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_REFLECTION_MAP);
    printf("GL_REFLECTION_MAP_ARB mode\n");
  }
  else if (mode == 1) {
    glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
    glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
    glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_NORMAL_MAP);
    printf("GL_NORMAL_MAP_ARB mode\n");
  }
}

/** Load the skybox picture.    
    @return void there is nothing to return here.
    @param target GLenum used in gluBuild2DMipmap.
    @param filename const char* URi of the file.
    @param flipTB GLboolean condition parameter 1 for texture to look right.
    @param flipLR GLboolean condition parameter 2 for texture to look right.
*/
void Skybox::load(GLenum target, const char *filename,
		  GLboolean flipTB, GLboolean flipLR)
{
  GLint w, h;
  GLenum format;
  GLubyte *img = LoadRGBImage( filename, &w, &h, &format );
  if (!img) {
    printf("Error: couldn't load texture image %s\n", filename);
    exit(1);
  }
  assert(format == GL_RGB);
  
  /* <sigh> the way the texture cube mapping works, we have to flip
   * images to make things look right.
   */
  if (flipTB) {
    const int stride = 3 * w;
    GLubyte temp[3*1024];
    int i;
    for (i = 0; i < h / 2; i++) {
      memcpy(temp, img + i * stride, stride);
      memcpy(img + i * stride, img + (h - i - 1) * stride, stride);
      memcpy(img + (h - i - 1) * stride, temp, stride);
    }
  }
  
  if (flipLR) {
    const int stride = 3 * w;
    GLubyte temp[3];
    GLubyte *row;
    int i, j;
    for (i = 0; i < h; i++) {
      row = img + i * stride;
      for (j = 0; j < w / 2; j++) {
	int k = w - j - 1;
	temp[0] = row[j*3+0];
	temp[1] = row[j*3+1];
	temp[2] = row[j*3+2];
	row[j*3+0] = row[k*3+0];
	row[j*3+1] = row[k*3+1];
	row[j*3+2] = row[k*3+2];
	row[k*3+0] = temp[0];
	row[k*3+1] = temp[1];
	row[k*3+2] = temp[2];
      }
    }
  }  
  gluBuild2DMipmaps(target, GL_RGB, w, h, format, GL_UNSIGNED_BYTE, img);
  free(img);
}

/** Load each picture of the sky box, top, bottom, left, right, front, back.
    @return void there is nothing to return here.
    @param void parameter.
*/
void Skybox::load_envmaps(void)
{
  load(GL_TEXTURE_CUBE_MAP_POSITIVE_X, "background/right.rgb", GL_TRUE, GL_FALSE);
  load(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, "background/left.rgb", GL_TRUE, GL_FALSE);
  load(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, "background/front.rgb", GL_FALSE, GL_TRUE);
  load(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, "background/back.rgb", GL_FALSE, GL_TRUE);
  load(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, "background/top.rgb", GL_TRUE, GL_FALSE);
  load(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, "background/bottom.rgb", GL_TRUE, GL_FALSE);  
}

