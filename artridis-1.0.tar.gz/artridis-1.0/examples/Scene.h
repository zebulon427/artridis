#ifndef SCENE_H
#define SCENE_H

#include <string.h>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdarg.h>

#include <GL/glut.h>
#include "../glm/glm.h"
#include "dirent32.h"

#if defined(_WIN32)
#include <sys/timeb.h>
#else
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/times.h>
#endif
#ifndef CLK_TCK
#define CLK_TCK 1000
#endif

#define MAX_OBJECT      100
#define BUFSIZE 512

extern float v;
extern float alpha;
extern float beta ;

extern GLfloat obs[3]; //position observer in outer world
extern GLfloat dir[3]; //Direction observer in outer world
extern GLfloat fovy, aspect, near, far;

extern GLenum mode;
extern GLfloat    weld_distance;	/* epsilon for welding vertices */
extern GLboolean  bounding_box;	        /* bounding box on? */
extern GLboolean  performance;	        /* performance counter on? */
extern GLboolean  stats;		/* statistics on? */
extern GLboolean  help; 		/* help on? */
extern GLboolean fogged;                /* fog on? */
extern GLboolean sub;                   /* sub windows on? */
extern GLboolean full_screen;           /* full screen on? */
extern GLMmodel*  model;		/* glm model data structure */

extern int window, subwindow, objectFlag, move, rotate, scaleflag, del;

/**
 * @param  key
 * @param  x
 * @param  y
 */
extern void keyboard (unsigned char key, int x, int y);

/**
 * @param  k
 * @param  x
 * @param  y
 */
extern void special (int k = 0, int x = 0, int y = 0 );

/**
 * @param  width
 * @param  height
 */
extern void reshape (int width = 0, int height = 0 );
extern void subreshape (int width = 0, int height = 0 );

extern int retrieveObjectID(int x, int y);

extern void mouse_function(int button, int state, int x, int y);

extern void init( GLboolean useImageFiles );

extern void loadObject(GLenum mode);                 
extern void initLoaded(GLenum mode);                
extern void initCaroussel(GLenum mode);

/**
 * @param  objectFlag
 *
 */
extern void selectObject();

/**
 * class Scene
 */
class Scene
{
 public:
  
  // Constructors/Destructors
  //  
    
  /**
   * Empty Constructor
   */
  Scene ( );
  
  /**
   * Empty Destructor
   */
  virtual ~Scene ( );
  
  // Static Public attributes
  //  
  
  // Public attributes
  //  
  
  // Public attribute accessor methods
  //  
  void moveObject();
  void rotateObject();
  void deleteObject();
  void scaleObject();  

  /**
   */
  void calcposobs ( );    
  
  /**
   * @param  x
   * @param  y
   * @param  s
   */
  void shadowtext (int x, int y, char * s );

  /**
   * @return float
   */
  float elapsed ( );

  /**
   * 
   * 
   */
   
protected:

  // Static Protected attributes
  //  

  // Protected attributes
  //  

public:

  // Protected attribute accessor methods
  //  

protected:

public:


  // Protected attribute accessor methods
  //  

protected:

private:

  // Static Private attributes
  //  

  // Private attributes
  //  

public:

  // Private attribute accessor methods
  //  

private:

public:

  // Private attribute accessor methods
  //  

private:

};

#endif // SCENE_H
