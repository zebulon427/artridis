/** @file Scene.cpp 
    @brief This program is holding various functionalities.
    * Calcposobs is a useful method from Mickael (Skizo@Hol.fr).
    * Much of this code was borrowed from SGI's tk OpenGL toolkit.
    @author Francois Gez
    @date 08/04/2007
*/

#include "Scene.h"
#include "Skybox.h"
#include "Object.h"

#define DATA_DIR "data/"
#define MAX_GRID_SIZE 40
#define SIZE (MAX_GRID_SIZE * MAX_GRID_SIZE * MAX_GRID_SIZE)


GLenum     mode = GL_RENDER;
GLfloat    weld_distance = 0.00001;	/* epsilon for welding vertices */
GLboolean  bounding_box = GL_FALSE;	/* bounding box on? */
GLboolean  performance = GL_FALSE;	/* performance counter on? */
GLboolean  stats = GL_FALSE;		/* statistics on? */
GLboolean  help = GL_FALSE;		/* statistics on? */
GLboolean  fogged = GL_FALSE;		/* fog on? */
GLboolean  sub = GL_FALSE;		/* sub windows on? */
GLboolean  full_screen = GL_FALSE;	/* full screen on? */

GLMmodel*  model;			/* glm model data structure*/

GLfloat fovy = 50.0, aspect = 1.5, near = 1.0, far = 750.0;

Scene ascene;
Skybox askybox;
Object anobject1;

int objectID = 199;
int window = 0, subwindow = 1;
int objectFlag = 0;
int move = 0, rotate = 0, scaleflag = 0, del = 0;

Object caroussel[MAX_OBJECT], loaded_object[MAX_OBJECT];

char* name[MAX_OBJECT] = {NULL};
char* loaded_name[MAX_OBJECT] = {NULL};

GLfloat xpos[MAX_OBJECT] = {0.0}, ypos[MAX_OBJECT] = {0.0}, zpos[MAX_OBJECT] = {0.0};
GLfloat xrot[MAX_OBJECT] = {0.0}, yrot[MAX_OBJECT] = {0.0}, zrot[MAX_OBJECT] = {0.0};
GLfloat sca[MAX_OBJECT] = {10.0};

GLfloat xpos_caroussel = 0.0, angle = 5.0, scale_object = 10.0;

// Constructors/Destructors
//  
/** Default Constructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Scene::Scene ( ) { }

/** Default Destructor
    @return void there is nothing to return from a constructor.
    @param void parameter.
*/
Scene::~Scene ( ) { }

//calcposobs
GLfloat obs[3] = { 5.0, -50.0, 0.0 };//position observer in outer world
GLfloat dir[3] = { 0.0, 0.0, 0.0 };//Direction observer in outer world
float v = 0.0;
float alpha = -5.0;
float beta =  75.0;

//  
// Methods
//  

/** Determine the camera position in the world.    
    @return void.
    @param void.
*/
void Scene::calcposobs ( ) {
  static double t0 = -1.0;
  double dt, t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
  if (t0 < 0.0)
    t0 = t;
  dt = t - t0;
  t0 = t;
  
  dir[0] = sin(alpha * M_PI / 180.0);
  dir[1] = cos(alpha * M_PI / 180.0) * sin(beta * M_PI / 180.0);
  dir[2] = cos(beta * M_PI / 180.0);
  
  if (dir[0] < 1.0e-5 && dir[0] > -1.0e-5)
    dir[0] = 0.0;
  if (dir[1] < 1.0e-5 && dir[1] > -1.0e-5)
    dir[1] = 0.0;
  if (dir[2] < 1.0e-5 && dir[2] > -1.0e-5)
    dir[2] = 0.0;   

  obs[0] += v * dir[0] * dt;
  obs[1] += v * dir[1] * dt;
  obs[2] += v * dir[2] * dt;

 if (obs[2] <= 0.0)
    obs[2] = 0.0;
  else if (obs[2] >= 20.0)
    obs[2] = 20.0;
else
  obs[2] += v * dir[2] * dt;
}

/**Function to draw some text at a particular position
 * @param  x
 * @param  y
 * @param  s
 */
void Scene::shadowtext (int x, int y, char * s ) {
  
  int lines;
  char* p;
  
  glDisable(GL_DEPTH_TEST);
  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  glLoadIdentity();
  glOrtho(0, glutGet(GLUT_WINDOW_WIDTH), 
	  0, glutGet(GLUT_WINDOW_HEIGHT), -1, 1);
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();
  glLoadIdentity();
  glColor3ub(1, 0, 0);
  glRasterPos2i(x+1, y-1);
  for(p = s, lines = 0; *p; p++) {
    if (*p == '\n') {
      lines++;
      glRasterPos2i(x+1, y-1-(lines*18));
    }
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *p);
  }
  glColor4f(1.0, 1.0, 1.0, 1.0);
  
  glRasterPos2i(x, y);
  for(p = s, lines = 0; *p; p++) {
    if (*p == '\n') {
      lines++;
      glRasterPos2i(x, y-(lines*18));
    }
    glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *p);
  }
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glMatrixMode(GL_MODELVIEW);
  glPopMatrix();
  glEnable(GL_DEPTH_TEST);
}

/**
 * @return float
 */
float Scene::elapsed (void) {
  static long begin = 0;
  static long finish, difference;
  
#if defined(_WIN32)
  static struct timeb tb;
  ftime(&tb);
  finish = tb.time*1000+tb.millitm;
#else
  static struct tms tb;
  finish = times(&tb);
#endif
  
  difference = finish - begin;
  begin = finish;
  
  return (float)difference/(float)CLK_TCK;
}

/**Keyboard interaction function.
 * @param  key
 * @param  x
 * @param  y
 */
void keyboard (unsigned char key, int x, int y) {
  GLint params[2];
  
  switch (key) {
  case 'h':
    help = !help;
    break;

  case GLUT_KEY_F11:
    full_screen = !full_screen;
    break;
    
  case 't':
    stats = !stats;
    break;
    
  case 'f':
    fogged = !fogged;
    break;
    
  case 'p':
    performance = !performance;
    break;

  case '<':
    glutSetWindow (subwindow);
    glutHideWindow ();
    break;

  case '>':
    glutSetWindow (subwindow);
    glutShowWindow ();
    break;
    
  case 'm':
    material_mode++;
    if (material_mode > 2)
      material_mode = 0;
    printf("material_mode = %d\n", material_mode);
    break;
    
  case 'w':
    glGetIntegerv(GL_POLYGON_MODE, params);
    if (params[0] == GL_FILL)
      glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    else
      glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    break;
    
  case 'c':
    if (glIsEnabled(GL_CULL_FACE)) {
      glDisable(GL_CULL_FACE);
    } else {
      glEnable(GL_CULL_FACE);
    }
    break;
    
  case 'n':
    facet_normal = !facet_normal;
    break;
    
  case 'e':
    scaleflag = 1;
    break;
    
  case 'E':
    scaleflag = 2;
    break;
    
  case 'o':
    glmWeld(model, weld_distance);
    printf("Welded\n");
    glmVertexNormals(model, smoothing_angle, GL_FALSE);
    break;
    
  case 'O':
    weld_distance += 0.01;
    printf("Weld distance: %.2f\n", weld_distance);
    glmWeld(model, weld_distance);
    glmFacetNormals(model);
    glmVertexNormals(model, smoothing_angle, GL_FALSE);
    break;
    
  case '-':
    smoothing_angle -= 1.0;
    printf("Smoothing angle: %.1f\n", smoothing_angle);
    glmVertexNormals(model, smoothing_angle, GL_FALSE);
    break;
    
  case '+':
    smoothing_angle += 1.0;
    printf("Smoothing angle: %.1f\n", smoothing_angle);
    glmVertexNormals(model, smoothing_angle, GL_FALSE);
    break;
    
  case 'R':
    {
      GLuint i;
      GLfloat swap;
      for (i = 1; i <= model->numvertices; i++) {
	swap = model->vertices[3 * i + 1];
	model->vertices[3 * i + 1] = model->vertices[3 * i + 2];
	model->vertices[3 * i + 2] = -swap;
      }
      glmFacetNormals(model);
      break;
    }
    
  case 'a': /* move forward */
    v += 1.0;
    break;
    
  case 'd':
    v -= 1.0;
    break;
    
  case 's':
    v = 0.0;
    break;
    
  case 9:
    //to implement with initial observer location
    obs[0] = 5.0;
    obs[1] = -60.0;
    obs[2] = 0.0;
    alpha = -5.0;
    beta = 75.0;
    break;
    
  case 'j':
    xpos_caroussel += 5;
    selectObject();      
    break;
    
  case 'k':
    objectFlag = 1;
    break;
    
  case 'l':
    xpos_caroussel -= 5;
    selectObject();
    break;
    
  case 'x':
    rotate = 1;
    break;
    
  case 'X':
    rotate = 2;
    break;
    
  case 'y':
    rotate = 3;
    break;
    
  case 'Y':
    rotate = 4;
    break;
    
  case 'z':
    rotate = 5;
    break;
    
  case 'Z':
    rotate = 6;
    break;
  case 8:
  case 127:
    del = 1;
    break;
    
  case 27:
    exit(0);
    break;
  }
  glutPostRedisplay();
}


/**Arrow keys control
 * @param  k
 * @param  x
 * @param  y
 */
void special (int k, int x, int y) {
  switch (k) {
  case GLUT_KEY_LEFT:
    alpha -= 1.0;
    break;
    
  case GLUT_KEY_RIGHT:
    alpha += 1.0;
    break;
    
  case GLUT_KEY_DOWN:
    beta += 1.0;
    break;
    
  case GLUT_KEY_UP:
    beta -= 1.0;
    break;  
  }
}


/**Reshape function
 * @param  width
 * @param  height
 */
void reshape (int width, int height) {
  
  glViewport(0, 0, width, height);
  
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity(); 
  
  gluPerspective(fovy, (GLfloat)width / (GLfloat)height, near, far);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

/**Callback function for reshaping the subwindow 
 * @param  w
 * @param  h
 */
void 
subreshape (int w, int h)
{
  glViewport (0, 0, w, h);
  glMatrixMode (GL_PROJECTION);
  glLoadIdentity ();
  
  gluPerspective(fovy, (GLfloat)w / (GLfloat)h, near, far/10);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

/** Mouse function to use for event handling.    
    @return void there is nothing to return here.
    @param button int which button.
    @param state pressed, clicked, etc....
    @param x int x position.
    @param y int y position.
*/
void mouse_function(int button, int state, int x, int y)
{
  objectID = retrieveObjectID(x, y); 
  
  if (state == GLUT_LEFT_BUTTON )
    {      
      if(move == 0 )
	{
	  move = 1;
	      bounding_box = 1;
}
      
      else if(move == 1)
	{
	  move = 0;
      bounding_box = 0;
	}
      
      else
	{
	  move = 0;
      bounding_box = 0;

	}
    } 
  
  else if (state == GLUT_RIGHT_BUTTON)
    {

    }
}

/**Selection picking of the mouse with Zdepth to the nearest.    
   @return int This selectedObject value tells whether an object was picked or not.
   @param x int What was the x position.
   @param y int What was the y position
*/
int retrieveObjectID(int x, int y)
{
  int objectsFound = 0;
  GLint viewportCoords[4] = {0};
  GLuint selectBuffer[32] = {0};
  
  glSelectBuffer(32, selectBuffer);
  glGetIntegerv(GL_VIEWPORT, viewportCoords);
  glMatrixMode(GL_PROJECTION);
  
  glPushMatrix();
  glRenderMode(GL_SELECT);
  glLoadIdentity();
  gluPickMatrix(x, viewportCoords[3] - y, 5.0, 5.0, viewportCoords);
  gluPerspective( fovy, aspect , near, far ); /* perspective projection*/    
  glMatrixMode(GL_MODELVIEW);
  initLoaded(GL_SELECT);
  objectsFound = glRenderMode(GL_RENDER);
  
  glMatrixMode(GL_PROJECTION);
  
  glPopMatrix();
  
  glMatrixMode(GL_MODELVIEW);
  
  if (objectsFound > 0)
    {
      GLuint lowestDepth = selectBuffer[1];
      
      int selectedObject = selectBuffer[3];
      
      for (int i = 1; i < objectsFound; i++)
        {
	  if (selectBuffer[(i*4)+1] < lowestDepth)
            {
	      lowestDepth = selectBuffer[(i*4)+1];
	      selectedObject = selectBuffer[(i*4)+3];
            }
        }
      return selectedObject;
    }    
  return 0;
}

// Accessor methods
//  
/**
 * @param s char*
 * @return int
 */
int strlen(char *s) /* added by RJH; source: K&R p99 */
{
  int n;
  
  for(n = 0; *s != '\0'; s++)
    {
      n++;
    }
  return n;
}

/**
 * @param s char*
 * @param t char*
 * @return int
 */
int strcmp(char *s, char *t) /* added by RJH; source: K&R p106 */
{
  for(;*s == *t; s++, t++)
    if(*s == '\0')
      return 0;
  return *s - *t;
}

/**
 * @param s char*
 * @param t char*
 * @return int
 */
int strend(char *s, char *t)
{
  int Result = 0;
  int s_length = 0;
  int t_length = 0;
  
  /* get the lengths of the strings */
  s_length = strlen(s);
  t_length = strlen(t);
  
  /* check if the lengths mean that the string t could fit at the string s */
  if(t_length <= s_length)
    {
      /* advance the s pointer to where the string t would have to start in string s */
      s += s_length - t_length;
      
    /* and make the compare using strcmp */
      if(0 == strcmp(s, t))
    {
      Result = 1;
    }
  }
  return Result;
}

/** Function that initialises the display of the available objects in the subwindow 
 * @param mode GLenum
 * @return void there is nothing to return
 */
void initCaroussel(GLenum mode)
{ 
  int i= 0;
  DIR* dirp;
  char* newname; 
  char* extension = ".obj";
  struct dirent* direntp;
  
  glInitNames();
  glPushName(0);
  
  dirp = opendir(DATA_DIR);
  
  if(dirp == NULL)
    {
      fprintf(stderr, "Cannot open %s\n", DATA_DIR);
      perror("Reason");
      return;
    }
  
  while( ( direntp = readdir(dirp)) != NULL)
    {
      newname = (char*)malloc(strlen(direntp->d_name) + strlen(DATA_DIR) + 1);
      strcpy(newname, DATA_DIR);
      strcat(newname, direntp -> d_name);
      
      if(strend(newname, extension))
	{
	  name[i] = newname;
	  glPushMatrix();		
	  
	  if (GL_SELECT == mode)
	    {
	      glLoadName(100 + i);
	    }     
	  
	  caroussel[i] = Object(100+i, name[i], xpos_caroussel+(5.0*i), 0.0, 0.0, 1.0);
	  glPopMatrix();
	  
	  glColor4f(1.0, 1.0, 1.0, 0.0);
	  i++;            
	}  
      
      else
	{
	  continue;
	}      
    }  
  free(newname);        
  closedir(dirp);
}


/** Function that enables the the movement of an object 
 * @param void
 * @return void there is nothing to return
 */
void Scene::moveObject()
{
  if(objectID != 0)
    {
      xpos[objectID-100] = obs[0];
      ypos[objectID-100] = obs[2];
      zpos[objectID-100] = obs[1]; 
      
      if(v >= 0.0)
	{                   
	  xpos[objectID-100] += v*dir[0]+dir[0]*10.0;
	  ypos[objectID-100] += v*dir[2]+dir[2]*10.0;
	  zpos[objectID-100] += v*dir[1]+dir[1]*10.0;
        }       
    }
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_BLEND);
    glColor4f(1.0, 0.0, 0.0, 0.1);
    glPushMatrix();
    glTranslatef(xpos[objectID-100], zpos[objectID-100], ypos[objectID-100]);
    glutSolidCube(1.0);
    glPopMatrix();
    glDisable(GL_BLEND);
		 glColor4f(1.0, 1.0, 1.0, 0.0);
}


/** Function that enable the rotation of an object 
 * @param void
 * @return void there is nothing to return
 */
void Scene::rotateObject()
{
  if(objectID != 0)
    {
      if(rotate == 1)
	xrot[objectID-100] += angle;
      else if (rotate == 2)
	xrot[objectID-100] -= angle;
      else if(rotate == 3)
	yrot[objectID-100] += angle; 
      else if(rotate == 4)
	yrot[objectID-100] -= angle;
      else if(rotate == 5)
	zrot[objectID-100] += angle;
      else if(rotate == 6)
	zrot[objectID-100] -= angle;       
    }
  rotate = 0;
}		


/** Function that enables the deletion of an object
 * @param void
 * @return void there is nothing to return
 */
void Scene::deleteObject()
{
  if(objectID != 0)
    {
      if(del == 1)
	{
	  loaded_name[objectID-100] = NULL; 
	} 
    }
  del = 0;
}	

/** Function that enables to shrink or to expand an object
 * @param void
 * @return void there is nothing to return
 */
void Scene::scaleObject()
{
  if(objectID != 0)
    {
      printf("scale_object: %f\n", scale_object);
      
      if(scaleflag == 1)
	{
	  --scale_object;
	  printf("scaleflag: %f\n", scaleflag);
	  sca[objectID-100] = scale_object;
	}
      else if (scaleflag == 2)
	{
	  ++scale_object;
	  sca[objectID-100] = scale_object;
	}
      else
	sca[objectID-100] = scale_object; 
    }
  scaleflag = 0;
}		


/** Function that set the loaded object in the world 
 * @param mode GLenum
 * @return void there is nothing to return
 */
void initLoaded(GLenum mode)
{ 
  glInitNames();
  glPushName(0);
  for(int i = 0; i< MAX_OBJECT; i++)
    {	 
      glPushMatrix();		
      
      if (GL_SELECT == mode)
	{
	  glLoadName(100 + i);
	}
      
      if(loaded_name[i] != NULL)
	{         
	  glTranslatef(loaded_object[i].getXpos(), 0.0, 0.0);
	  glTranslatef(0.0, loaded_object[i].getYpos(), 0.0);
	  glTranslatef(0.0, 0.0, loaded_object[i].getZpos());
	  glRotatef(xrot[i], 1.0, 0.0, 0.0);
	  glRotatef(zrot[i], 0.0, 1.0, 0.0);
	  glRotatef(yrot[i], 0.0, 0.0, 1.0);                            
	  glTranslatef(-loaded_object[i].getXpos(), 0.0, 0.0);
	  glTranslatef(0.0, -loaded_object[i].getYpos(), 0.0);
	  glTranslatef(0.0, 0.0, -loaded_object[i].getZpos());
	  
	  loaded_object[i] = Object(100+i, loaded_name[i], xpos[i], zpos[i], ypos[i], sca[i]);
	}
      glPopMatrix();
    }     
  glColor4f(1.0, 1.0, 1.0, 0.0);
} 


/** Function that identify the object to load from the caroussel
 * @param void
 * @return void there is nothing to return
 */
void selectObject()
{
  for(int i = 0; i< MAX_OBJECT; i++)
    {	     
      caroussel[i].setXpos(xpos_caroussel);
      printf("anobject2 xpos_caroussel: %f\n",caroussel[i].getXpos());
    }  
}


/**   
 * @param mode GLenum
 * @return void there is nothing to return
 */
void loadObject(GLenum mode)
{
  glInitNames();
  glPushName(0);
  
  glPushMatrix();		
  for(int i = 0;i<MAX_OBJECT;i++)
    {
      if (GL_SELECT == mode)
	{
	  glLoadName(100+i);
	}
      if (caroussel[i].getXpos() == 0.0)    
	{
	  loaded_name[i] = name[i];          
	}
    }
    glPopMatrix();
} 


/** Function that initialises the display in both the main and the sub window 
 * @param mode GLenum
 * @return void there is nothing to return
 */
 void
init(GLboolean useImageFiles)
{
   float fogcolor[4] = { 0.6, 0.7, 0.7, 1.0 };
  GLenum filter;
  
  /*
  // check for extension
  {
    
    char *exten = (char *) glGetString(GL_EXTENSIONS);
    if (!strstr(exten, "GL_ARB_texture_cube_map")) {
      printf("Sorry, this demo requires GL_ARB_texture_cube_map\n");
      exit(0);
    }
    
  }
    */
  printf("GL_RENDERER: %s\n", (char *) glGetString(GL_RENDERER));
  
  askybox.load_envmaps();
  glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, filter);
  glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, filter);
  glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
  glTexParameteri(GL_TEXTURE_CUBE_MAP    , GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
  
  glEnable(GL_TEXTURE_CUBE_MAP    );
  
   glClearDepth(1.0);
   glDepthFunc(GL_LEQUAL);
   glShadeModel(GL_SMOOTH);
   glEnable(GL_DEPTH_TEST);

  glClearColor(.3, .3, .3, 0);
  glColor3f( 1.0, 1.0, 1.0 );

   glDisable(GL_BLEND);
   glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

  askybox.set_mode(0);

  glHint(GL_CLIP_VOLUME_CLIPPING_HINT_EXT, GL_FASTEST);
}
